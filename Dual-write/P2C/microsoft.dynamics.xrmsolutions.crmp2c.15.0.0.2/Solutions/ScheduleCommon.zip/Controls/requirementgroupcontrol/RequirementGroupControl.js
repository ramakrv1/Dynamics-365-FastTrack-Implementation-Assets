/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsOutputs.g.ts" />
/// <reference path="mscrm.d.ts" />
/// <reference path="mscrmcomponents.d.ts" />
/// <reference path="CommonControl.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="CommonReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var RequirementGroupControl;
    (function (RequirementGroupControl_1) {
        'use strict';
        var RequirementGroupControl = (function () {
            /**
             * Empty constructor.
             */
            function RequirementGroupControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            RequirementGroupControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                var _this = this;
                this.context = context;
                this.container = container;
                if (!MscrmCommon.ControlUtils.Object.isNullOrUndefined(this.context.client.trackContainerResize)) {
                    this.context.client.trackContainerResize(true);
                }
                this.innerFrame = document.createElement("iframe");
                this.innerFrame.setAttribute("style", "height: 100%; width:100%");
                var webResourceHash = "";
                if (this.context.orgSettings && this.context.orgSettings.webResourceHash && this.context.orgSettings.webResourceHash.length !== 0) {
                    // Add leading slash to web resource hash
                    webResourceHash = "/" + this.context.orgSettings.webResourceHash;
                }
                this.innerFrame.src = "" + context.page.getClientUrl() + webResourceHash + "/webresources/msdyn_/RequirementGroupControl/html/index.html";
                this.container.appendChild(this.innerFrame);
                this.innerFrame.contentWindow.registerUpdateViewHandler = function (handler) {
                    _this.innerHandler = handler;
                    handler(_this.context);
                };
                var UCIElementsHeight = (window.innerWidth <= RequirementGroupControl.windowInnerWidthThreshold) ? RequirementGroupControl.mobileViewHeight : RequirementGroupControl.webViewHeight;
                var availableHeight = window.innerHeight - UCIElementsHeight;
                this.container.style.height = availableHeight + "px";
                this.container.style.minHeight = RequirementGroupControl.minHeight + "px";
                //add resize event to handle changing control height on browser resize
                var that = this;
                window.addEventListener('resize', function (event) {
                    var UCIElementsHeight = (window.innerWidth <= RequirementGroupControl.windowInnerWidthThreshold) ? RequirementGroupControl.mobileViewHeight : RequirementGroupControl.webViewHeight;
                    var availableHeight = window.innerHeight - UCIElementsHeight;
                    that.container.style.height = availableHeight + "px";
                }, true);
                this.innerFrame.contentWindow.controlContext = this.context;
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            RequirementGroupControl.prototype.updateView = function (context) {
                this.innerHandler(context);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            RequirementGroupControl.prototype.getOutputs = function () {
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            RequirementGroupControl.prototype.destroy = function () {
            };
            return RequirementGroupControl;
        }());
        /**
         * 474 is the total height of all UCI components & padding for the section in web view; 327 is for mobile view
         */
        RequirementGroupControl.windowInnerWidthThreshold = 480;
        RequirementGroupControl.mobileViewHeight = 327;
        RequirementGroupControl.webViewHeight = 474;
        RequirementGroupControl.minHeight = 280;
        RequirementGroupControl_1.RequirementGroupControl = RequirementGroupControl;
    })(RequirementGroupControl = MscrmControls.RequirementGroupControl || (MscrmControls.RequirementGroupControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=RequirementGroupControl.js.map